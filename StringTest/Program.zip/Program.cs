﻿// 1. You need to get longer Main string as input from the user (Refer example below).
// 2. You need to get the shorter string as input from the user (Refer example below) 
//which is the sub string of the first input.
// 3. You need to find the number of occurrences of the substring in the main string.
// Ex:
// Input:
// Main String: blablablabla
// String to be searched: la
// Output: string searched count is 4
using System;
namespace StringTest;
class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Get input:");
        string input = Console.ReadLine();
        Console.WriteLine("Get smaller input:");
        string testStr = Console.ReadLine();
        string[] str = input.Split(testStr);
        int count = 0;
        for (int i = 0; i < str.Length; i++)
        {
            if (testStr == str[i])
            {
                count++;
            }
        }
        Console.Write(count);
    }
}